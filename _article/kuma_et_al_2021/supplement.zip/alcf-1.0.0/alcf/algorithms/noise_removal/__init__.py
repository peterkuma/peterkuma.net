from . import default

NOISE_REMOVAL = {
	'default': default,
}
