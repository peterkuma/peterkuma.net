from . import default

CLOUD_BASE_DETECTION = {
	'default': default,
}
