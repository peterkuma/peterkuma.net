from . import default

CALIBRATION = {
	'default': default,
}
