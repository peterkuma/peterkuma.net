from . import default

CLOUD_DETECTION = {
	'default': default,
}
