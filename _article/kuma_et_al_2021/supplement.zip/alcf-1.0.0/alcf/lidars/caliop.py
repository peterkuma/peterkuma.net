import numpy as np

WAVELENGTH = 532 # nm
CALIBRATION_COEFF = 1.0
SURFACE_LIDAR = False
SC_LR = None
