import ds_format as ds
import os

def read(dirname, track, warnings=[]):
	pass
# 	time = track['time']
# 	t1, t2 = time[0], time[-1]
# 	d_cli = ds.read(dirname, ['cli'], {'time': [t1, t2]})
# 	d_clw = ds.read(dirname, ['clw'], {'time': [t1, t2]})
# 	ds.read(dirname)

# indexing
# - mask
# - list of indexes
# - list of values
# - index range
# - value range
