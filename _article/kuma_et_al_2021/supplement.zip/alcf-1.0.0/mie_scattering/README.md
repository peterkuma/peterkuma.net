Mie scattering code
===================

This directory contains code for calculation of Mie scattering parameters
required by the COSP/ACTSIM lidar simulator.

Please see [alcf-lidar.github.com/documentation/lidar_simulator/](https://alcf-lidar.github.io/documentation/lidar_simulator/)
for documentation of how to use this code.
